package com.example.test3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class Member_MyCMP_Activity extends AppCompatActivity {

    private ListView listView;
    private Member_MyCMP_adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member__my_cmp_);


        listView = (ListView)findViewById(R.id.complainlist);
        adapter = new Member_MyCMP_adapter();

        adapter.addItem("2019/06/05 16:32:22","중얼거리는 소리를 냄");
        adapter.addItem("2019/06/05 16:32:25","냄새가 남");


        listView.setAdapter(adapter);
    }
}
